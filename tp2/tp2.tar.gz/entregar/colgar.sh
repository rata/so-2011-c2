#!/bin/bash

cat << EOF > asd
	SOY RATA
	LETRA 6 3 Y
	LETRA 6 3 Y
EOF

nc localhost 5481 < asd
